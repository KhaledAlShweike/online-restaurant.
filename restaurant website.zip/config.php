<?php

$conn = mysqli_connect('localhost','root','','food_db') or die('connection failed');

?>